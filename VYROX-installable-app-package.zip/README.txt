VYROX — Installable Web App Package

CONTENTS
- index.html: VYROX website
- manifest.webmanifest: app name, icon and install settings
- service-worker.js: offline app-shell cache
- vyrox-icon.svg: app icon

IMPORTANT
A PWA cannot be installed from a ZIP or by opening the HTML file directly.
It must be served from a secure HTTPS website (or localhost for testing).
This package does not create a public website or activate real login/OTP,
payments, cloud sync, or server-side security.

DEPLOYMENT
1. Upload every file in this folder to the same directory on an HTTPS web host.
2. Open the HTTPS address in Chrome or Edge.
3. Android: Chrome menu (three dots) > Install app or Add to Home screen.
4. Windows: Edge/Chrome menu > Apps > Install this site as an app
   (or use the install icon in the address bar when shown).

The app shell can cache for offline opening after the first successful online visit.
Features requiring a server or internet may still need a connection.
